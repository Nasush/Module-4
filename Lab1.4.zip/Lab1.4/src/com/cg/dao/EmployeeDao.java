package com.cg.dao;

import com.cg.dto.Employee;

public interface EmployeeDao
{
	Employee getEmpList(int empId);
}
