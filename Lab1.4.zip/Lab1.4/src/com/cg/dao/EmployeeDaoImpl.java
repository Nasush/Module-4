package com.cg.dao;

import java.util.List;

import com.cg.dto.Employee;

public class EmployeeDaoImpl implements EmployeeDao
{
	List<Employee> emp;
	
	public List<Employee> getEmp()
	{
		return emp;
	}

	public void setEmp(List<Employee> emp) 
	{
		this.emp = emp;
	}

	public Employee getEmpList(int empId) 
	{

		Employee ee = null;
		for(Employee e:emp)
		{
			if(e.getEmpId() == empId)
			{
				ee = e;
			}
			else
			{
				;
			}
		}
		return ee;
	}

}
