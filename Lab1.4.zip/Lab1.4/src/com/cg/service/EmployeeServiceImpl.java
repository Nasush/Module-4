package com.cg.service;

import com.cg.dao.EmployeeDao;
import com.cg.dao.EmployeeDaoImpl;
import com.cg.dto.Employee;

public class EmployeeServiceImpl implements EmployeeService
{
	EmployeeDaoImpl employeedao;
	
	
	public EmployeeDaoImpl getEmployeedao()
	{
		return employeedao;
	}


	public void setEmployeedao(EmployeeDaoImpl employeedao)
	{
		this.employeedao = employeedao;
	}


	@Override
	public Employee getEmpList(int empId) 
	{
		return employeedao.getEmpList(empId);
	}

}
