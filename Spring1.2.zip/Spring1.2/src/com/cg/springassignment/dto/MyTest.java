package com.cg.springassignment.dto;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class MyTest 
{
	public static void main(String[] args) 
	{
		ApplicationContext ap=new ClassPathXmlApplicationContext("spring.xml");
		Employee emp=(Employee) ap.getBean("emp");
		emp.getAllEmpDetails();
	}
}
