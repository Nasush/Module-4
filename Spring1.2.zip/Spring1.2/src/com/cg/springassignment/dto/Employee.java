package com.cg.springassignment.dto;

public class Employee implements EmployeeDetails
{
	private int empAge;
	private int employeeId;
	private String employeeName;
	private double salary;
	SBU businessUnit;
	
	
	public int getEmpAge() {
		return empAge;
	}
	public void setEmpAge(int empAge) {
		this.empAge = empAge;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public SBU getBusinessUnit() {
		return businessUnit;
	}
	public void setBusinessUnit(SBU businessUnit) {
		this.businessUnit = businessUnit;
	}
	@Override
	public void getAllEmpDetails() 
	{
		System.out.println("Employee details");
		System.out.println("----------------------------");
		System.out.println("Employee [empAge=" + empAge + ", empId=" + employeeId
				+ ", empName=" + employeeName + ", empSalary=" + salary);
		System.out.println("sbu details=SBU [sbuCode="+businessUnit.getSbuId()+
				", sbuHead="+businessUnit.getSbuHead()+", sbuName="+businessUnit.getSbuName()+"]]" );
		
	}
	
	
	
}
