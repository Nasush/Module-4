package com.cg.springmvctwo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.cg.springmvctwo.dto.Mobile;
import com.cg.springmvctwo.service.IMobileService;

@Controller
public class MobileController
{
	@Autowired
	IMobileService mobileservice;
	@RequestMapping(value="showall",method=RequestMethod.GET)
	public ModelAndView allMobileData()
	{
		List<Mobile> mobData=mobileservice.showAllMobile();
		
		return new ModelAndView("mobileshow","temp",mobData);
		
	}
	@RequestMapping(value="delete",method=RequestMethod.GET)
	public String MobileDelete(@RequestParam("id")int mobid)
	{
		//System.out.println("Id Is------" +mobid);
		mobileservice.deleteMobile(mobid);
		return "redirect:/showall";
	}
	@RequestMapping(value="update",method=RequestMethod.GET)
	public ModelAndView updateTrainee(@RequestParam ("id1") int id,
			@ModelAttribute ("myUpdate")Mobile mob)
	{
		System.out.println("Id Is------" +id);
		List<Mobile> myData=mobileservice.showMobileById(id);
		return new ModelAndView( "updatemobile","temp",myData);
	}
	@RequestMapping(value="update1",method=RequestMethod.POST)
	public String update(@ModelAttribute ("myUpdate")Mobile mob)
	{
		
		mobileservice.updateMobile(mob);
		return "redirect:/showall";
		
	}
	
}
