package com.cg.springassignment.dto;

public interface EmployeeDetails 
{
	public void getAllEmployeeDetails();
}
