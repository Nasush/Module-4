package com.cg.dto;

import java.util.List;
public class SBU implements EmpDetails
{
	String sbuId;
	String sbuName;
	String sbuHead;
	List<Employee> emp;
	
	public String getSbuId() {
		return sbuId;
	}
	public void setSbuId(String sbuId) {
		this.sbuId = sbuId;
	}
	public String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	public String getSbuHead() {
		return sbuHead;
	}
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	public List<Employee> getEmp() {
		return emp;
	}
	public void setEmp(List<Employee> emp) {
		this.emp = emp;
	}
	
	@Override
	public void getSbuDetails() 
	{
		System.out.println("SBU Details");
		System.out.println("-----------------");
		System.out.println("sbuCode="+sbuId+","
		+ " sbuHead="+sbuHead+","
				+ " sbuName="+sbuName);
		
		System.out.println("Employee Details :-----------------");
		for(Employee employee:emp)
		System.out.println("Employee [empAge="+employee.getEmpAge()+", "
		+ "empId="+employee.getEmployeeId()+", empName="+employee.employeeName+", "
		+ "empSalary="+employee.getSalary()+"],");
		
		
		
		
	}
	
}
