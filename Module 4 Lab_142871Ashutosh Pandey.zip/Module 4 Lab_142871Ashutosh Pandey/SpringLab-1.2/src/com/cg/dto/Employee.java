package com.cg.dto;


public class Employee implements EmpDetails
{
	int empAge;
	int employeeId;
	String employeeName;
	Double salary;
	SBU businessUnit;
	
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	public SBU getBusinessUnit() {
		return businessUnit;
	}
	public void setBusinessUnit(SBU businessUnit) {
		this.businessUnit = businessUnit;
	}
	
	public int getEmpAge() {
		return empAge;
	}
	public void setEmpAge(int empAge) {
		this.empAge = empAge;
	}
	@Override
	public void getSbuDetails() 
	{
		System.out.println("Employee Details");
		System.out.println("-----------------");
		System.out.println("Employee [empAge="+empAge+", "
		+ "empId="+employeeId+", empName="+employeeName+", "
		+ "empSalary="+salary+"\nsbu details=SBU "
		+ "[sbuCode="+businessUnit.getSbuId()+","
		+ " sbuHead="+businessUnit.getSbuHead()+","
				+ " sbuName="+businessUnit.getSbuName()+"]]");
		
		
		
	}
	
}
