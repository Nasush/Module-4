package com.cg.dto;

public interface SBUInt 
{
	public void getAllSBUDetail();
	
}
