package com.cg.dto;

import java.util.List;

public class SBusinessUnit implements SBUInt
{
int sbuId;
String sbuName;
String sbuHead;
List<Employee> empList;
public List<Employee> getEmpList() {
	return empList;
}
public void setEmpList(List<Employee> empList) {
	this.empList = empList;
}
public int getSbuId() {
	return sbuId;
}
public void setSbuId(int sbuId) {
	this.sbuId = sbuId;
}
public String getSbuName() {
	return sbuName;
}
public void setSbuName(String sbuName) {
	this.sbuName = sbuName;
}
public String getSbuHead() {
	return sbuHead;
}
public void setSbuHead(String sbuHead) {
	this.sbuHead = sbuHead;
}
@Override
public void getAllSBUDetail() 
{
	System.out.println("SBU Details");
	System.out.println("----------------");
	System.out.println("sbuId=" + sbuId + ", sbuName=" + sbuName
			+ ", sbuHead=" + sbuHead);
	System.out.println("Employee Details:----------------");
	for(Employee e:empList)
	{
		System.out.println(e.toString());
	}
	
}






}
