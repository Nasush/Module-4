package com.cg.dto;

import java.util.List;



public class Employee
{
	int employeeId;
	String employeeName;
	double employeeSal;
	
	

	

	public int getEmployeeId() 
	{
		return employeeId;
	}

	public void setEmployeeId(int employeeId)
	{
		this.employeeId = employeeId;
	}

	public String getEmployeeName()
	{
		return employeeName;
	}

	public void setEmployeeName(String employeeName)
	{
		this.employeeName = employeeName;
	}

	public double getEmployeeSal()
	{
		return employeeSal;
	}

	public void setEmployeeSal(double employeeSal) 
	{
		this.employeeSal = employeeSal;
	}

	

	

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName="
				+ employeeName + ", employeeSal=" + employeeSal + 
				 "]";
	}


	
		
	}



	
	

