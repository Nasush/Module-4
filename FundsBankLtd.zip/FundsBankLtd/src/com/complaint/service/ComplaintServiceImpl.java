package com.complaint.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.complaint.bean.ComplaintBean;
import com.complaint.dao.IComplaintDAO;


@Service("complaintService")
public class ComplaintServiceImpl implements IComplaintService {
	
	@Autowired
	IComplaintDAO complaintDao;
	
	@Override
	public int addComplaintDetails(ComplaintBean bean)
			 {
		String category=bean.getCategory();
		System.out.println(category);
		bean.setStatus("Open");
			if(category.equals("Internet Banking"))
			{
				bean.setPriority("High");
			}
			else if(category.equals("General Banking")){
				bean.setPriority("Medium");
			}
			else
			{
				bean.setPriority("Low");

			}
		return complaintDao.addComplaintDetails(bean);
	}

	@Override
	public ComplaintBean checkStatus(int complaintId)
	{

		
		return complaintDao.checkStatus(complaintId);
	}

}
