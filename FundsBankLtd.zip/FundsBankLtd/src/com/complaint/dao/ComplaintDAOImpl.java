package com.complaint.dao;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.complaint.bean.ComplaintBean;




@Repository("complaintDao")
@Transactional
public class ComplaintDAOImpl implements IComplaintDAO {
	
	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public int addComplaintDetails(ComplaintBean bean)
			 {
		int id=0;
		
	
		
		
			entityManager.persist(bean);
			entityManager.flush();
			id=bean.getComplaintId();
	
		return id;
	}

	@Override
	public ComplaintBean checkStatus(int complaintId)
		 {
		
		
		ComplaintBean bean=entityManager.find(ComplaintBean.class, complaintId);
			
		
		return bean;
		
	}

}
