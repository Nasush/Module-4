package com.cg.service;

import java.util.List;

import com.cg.dto.EmployeeDetails;
import com.cg.dto.EmployeeLeaveDetails;

public interface IQueryService
{
	public List<EmployeeLeaveDetails> showLeaveDetailsById(int empid);
	public boolean searchEmployeeId(int empid);
	public boolean searchEmployeeLeaves(int empid);
	public EmployeeDetails getEmpDetails(int empid);
}
