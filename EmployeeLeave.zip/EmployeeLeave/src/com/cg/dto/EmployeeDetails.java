package com.cg.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee_details")
public class EmployeeDetails
{
	@Id
	private Integer empid;
	private String ename;
	private String address;
	@Column(name="leaves_avail")
	private Integer leavesAvailable;
	public Integer getEmpid() {
		return empid;
	}
	public void setEmpid(Integer empid) {
		this.empid = empid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Integer getLeavesAvailable() {
		return leavesAvailable;
	}
	public void setLeavesAvailable(Integer leavesAvailable) {
		this.leavesAvailable = leavesAvailable;
	}
	
	
}
