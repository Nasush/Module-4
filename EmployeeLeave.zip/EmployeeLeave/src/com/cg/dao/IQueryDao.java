package com.cg.dao;

import java.util.List;

import com.cg.dto.EmployeeDetails;
import com.cg.dto.EmployeeLeaveDetails;

public interface IQueryDao
{
	public List<EmployeeLeaveDetails> showLeaveDetailsById(int empId);
	public boolean searchEmployeeId(int empId);
	public boolean searchEmployeeLeaves(int empId);
	public EmployeeDetails getEmpDetails(int empId);
}
