package com.cg.service;

import com.cg.dto.Mobile;

public interface MobileService
{void addMobile(Mobile mobile);
void updateMobile(Mobile mobile);
void deleteMobile(Mobile mobile);
Mobile findMobile(int mid);

}
