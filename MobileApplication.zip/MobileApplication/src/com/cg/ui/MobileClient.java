package com.cg.ui;

import java.util.Scanner;

import com.cg.dto.Mobile;
import com.cg.service.MobileService;
import com.cg.service.MobileServiceImpl;


public class MobileClient 
{

	public static void main(String[] args)
	{
		MobileService mser = new MobileServiceImpl();
		int choice;
		Scanner sc = new Scanner(System.in);

		do
		{
			System.out.println("1.Add Mobile");
			System.out.println("2.Update Mobile");
			System.out.println("3.Search Mobile");
			System.out.println("4.Delete Mobile");
			System.out.println("5. Exit");
			System.out.println(" Enter your choice");

			choice=sc.nextInt();

			switch(choice)
			{
			case 1:
				System.out.println("Enter Mobile Name");
				String mname=sc.next();
				System.out.println("Enter Price");
				double price =sc.nextDouble();
				System.out.println("Enter Quantity");
				int qty=sc.nextInt();
				Mobile mobile=new Mobile();
				mobile.setMname(mname);
				mobile.setPrice(price);
				mobile.setQty(qty);
				mser.addMobile(mobile);
				System.out.println("Mobile Details Added");
				break;


			case 2:
				System.out.println("Enter Mobile ID to be Updated");
				int mId=sc.nextInt();
				System.out.println("Enter Mobile Name to be Updated");
				String mName=sc.next();
				System.out.println("Enter Price to be Updated");
				double price1 =sc.nextDouble();
				System.out.println("Enter Quantity to be updated");
				int qty1=sc.nextInt();
				Mobile mobile3=new Mobile();
				mobile3.setMobileid(mId);
				mobile3.setMname(mName);
				mobile3.setPrice(price1);
				mobile3.setQty(qty1);
				mser.updateMobile(mobile3);
				System.out.println("Mobile Data Updated");
				
				break;

			case 3:
				System.out.println("Enter the mobile Id To Search");
				int mid=sc.nextInt();

				Mobile mobile1=mser.findMobile(mid);
				System.out.println(mobile1);
				break;

			case 4:
				System.out.println("Enter mobile id to delete:");
				int mid1=sc.nextInt();
				Mobile mobile2= mser.findMobile(mid1);
				mser.deleteMobile(mobile2);
				System.out.println("Mobile Details are deleted");
				break;
			case 5:
				System.exit(0);
				break;
			}


		}
		while(true);
	}

}


