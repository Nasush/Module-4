package com.cg.dto;

public interface EmpDetails 
{
	public void getSbuDetails();
}
