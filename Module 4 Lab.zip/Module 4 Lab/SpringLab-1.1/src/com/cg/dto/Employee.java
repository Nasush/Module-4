package com.cg.dto;

public class Employee implements EmployeeDetails
{
	int empId;
	String empName;
	Double sal;
	String empBu;
	int age;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Double getSal() {
		return sal;
	}
	public void setSal(Double sal) {
		this.sal = sal;
	}
	public String getEmpBu() {
		return empBu;
	}
	public void setEmpBu(String empBu) {
		this.empBu = empBu;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public void getEmpDetails() 
	{
		System.out.println("Employee Details");
		System.out.println("-----------------");
		System.out.println("Employee Id : "+empId);
		System.out.println("Employee Name : "+empName);
		System.out.println("Employee Salary : "+sal);
		System.out.println("Employee BU : "+empBu);
		System.out.println("Employee Age : "+age);
		
	}
	
	
}
