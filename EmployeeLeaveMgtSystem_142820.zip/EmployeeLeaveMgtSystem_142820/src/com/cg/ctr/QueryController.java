package com.cg.ctr;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.dto.EmployeeDetails;
import com.cg.dto.EmployeeLeaveDetails;
import com.cg.service.IQueryService;


@Controller
public class QueryController 
{
	@Autowired
	IQueryService employeeservice;
	
	@RequestMapping(value="Move",method=RequestMethod.GET)
	public String Login()
	{
		return "Home";
	}
	
	@RequestMapping(value="show",method=RequestMethod.GET)
	public ModelAndView showEmpLeave(@RequestParam("empid") int empid,
			Model model)
	{
		boolean empCheck=employeeservice.searchEmployeeId(empid);
		if(empCheck==false)
		{
			String message="This Employee ID Does not exist...";
			return new ModelAndView("Home","msg",message);
		}
		else
		{
			List<EmployeeLeaveDetails> Leaves=employeeservice.showLeaveDetailsById(empid);
			EmployeeDetails empDetails=employeeservice.getEmpDetails(empid);
			model.addAttribute("empId",empDetails.getEmpid());
			model.addAttribute("empName",empDetails.getEname());
			if(Leaves.isEmpty())
			{
				String msg="No leave record found";
				
				return new ModelAndView("viewLeaveDetails","msg",msg);
			}
			else
			{
				return new ModelAndView("viewLeaveDetails", "temp", Leaves);
			}
		}
			
			
	
		
	}

	
}