package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IQueryDao;
import com.cg.dto.EmployeeDetails;
import com.cg.dto.EmployeeLeaveDetails;
@Service("employeeservice")
@Transactional
public class QueryServiceImpl implements IQueryService
{
	@Autowired
	IQueryDao employeeDao;
	
	@Override
	public List<EmployeeLeaveDetails> showLeaveDetailsById(int empid) 
	{
		return employeeDao.showLeaveDetailsById(empid);
	}

	@Override
	public EmployeeDetails getEmpDetails(int empid)
	{
		
		return employeeDao.getEmpDetails(empid);
	}

	@Override
	public boolean searchEmployeeId(int empid)
	{
		
		return employeeDao.searchEmployeeId(empid);
	}

	@Override
	public boolean searchEmployeeLeaves(int empid) {
		// TODO Auto-generated method stub
		return employeeDao.searchEmployeeLeaves(empid);
	}

}
