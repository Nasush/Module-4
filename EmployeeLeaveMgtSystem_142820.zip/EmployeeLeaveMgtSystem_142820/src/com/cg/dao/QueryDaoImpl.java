package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.dto.EmployeeDetails;
import com.cg.dto.EmployeeLeaveDetails;


@Repository("employeeDao")
public class QueryDaoImpl implements IQueryDao
{
	@PersistenceContext
	EntityManager entitymanager;
	@Override
	public List<EmployeeLeaveDetails> showLeaveDetailsById(int empid) 
	{
		Query queryOne=entitymanager.createQuery("FROM EmployeeLeaveDetails "
				+ " WHERE empid=:eId");
		queryOne.setParameter("eId", empid);
		
		 List<EmployeeLeaveDetails> myList=queryOne.getResultList();
		 return myList;
	}
	
	
	@Override
	public boolean searchEmployeeId(int empid) 
	{
		EmployeeDetails emp=entitymanager.find(EmployeeDetails.class, empid);
	if(emp != null)
	{
		return true;
	}
	else
	{
		return false;
	}
	}
	
	
	@Override
	public EmployeeDetails getEmpDetails(int empid) 
	{
		
		EmployeeDetails mList=entitymanager.find(EmployeeDetails.class,empid);
		return mList;
	}
	
	@Override
	public boolean searchEmployeeLeaves(int empid)
	{
		
		Query queryThree=entitymanager.createQuery("FROM "
				+ "EmployeeLeaveDetails where empid=:id");
		queryThree.setParameter("id", empid);
		List<EmployeeDetails> empList1=queryThree.getResultList();
		if(empList1.isEmpty())
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}
	
	
	
}

