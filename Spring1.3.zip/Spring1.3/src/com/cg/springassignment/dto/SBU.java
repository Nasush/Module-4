package com.cg.springassignment.dto;

import java.util.List;

public class SBU implements SBUdetails
{
	private String sbuCode;
	private String sbuName;
	private String sbuHead;
	List<Employee> empList;
	public String getSbuCode() {
		return sbuCode;
	}
	public void setSbuCode(String sbuCode) {
		this.sbuCode = sbuCode;
	}
	public String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	public String getSbuHead() {
		return sbuHead;
	}
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	public List<Employee> getEmpList() {
		return empList;
	}
	public void setEmpList(List<Employee> empList) {
		this.empList = empList;
	}
	@Override
	public void getAllSbuDetails() 
	{
		System.out.println("SBU details");
		System.out.println("------------------");
		System.out.println("sbuCode=" + sbuCode + ", sbuHead=" + sbuHead
				+ ", sbuName=" + sbuName);
		System.out.println("Employee details:--------------------------");
		for(Employee emp:empList)
		{
			System.out.println("[Employee [empAge="+emp.getEmployeeAge()+
					", empId="+emp.getEmployeeId()+
					", empName="+emp.getEmployeeName()+
					", empSalary="+emp.getSalary()+"],");
				
		}
	}
	
}
