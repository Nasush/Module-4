package com.cg.springassignment.dto;

public interface SBUdetails 
{
	public void getAllSbuDetails();
}
