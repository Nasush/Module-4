package com.cg.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.dto.EmployeeInt;
import com.cg.dto.SBusinessUnit;



public class MyTest {

	public static void main(String[] args)
	{
		ApplicationContext ap =
				new ClassPathXmlApplicationContext("Spring.xml");
		EmployeeInt e=(EmployeeInt) ap.getBean("emp");
		e.getAllEmployeeDetail();
	}

}
