package com.cg.dto;

import java.util.List;



public class Employee implements EmployeeInt
{
	int employeeId;
	String employeeName;
	double employeeSal;
	SBusinessUnit sBU;
	
	public Employee()
	{
		super();
	}

	

	public int getEmployeeId() 
	{
		return employeeId;
	}

	public void setEmployeeId(int employeeId)
	{
		this.employeeId = employeeId;
	}

	public String getEmployeeName()
	{
		return employeeName;
	}

	public void setEmployeeName(String employeeName)
	{
		this.employeeName = employeeName;
	}

	public double getEmployeeSal()
	{
		return employeeSal;
	}

	public void setEmployeeSal(double employeeSal) 
	{
		this.employeeSal = employeeSal;
	}

	

	public SBusinessUnit getsBU() 
	{
		return sBU;
	}



	public void setsBU(SBusinessUnit sBU) 
	{
		this.sBU = sBU;
	}



	public Employee(int employeeId, String employeeName, double employeeSal,
			SBusinessUnit sBU) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeSal = employeeSal;
		this.sBU = sBU;
	}



	@Override
	public void getAllEmployeeDetail()
	{
		System.out.println( "Employee [employeeId=" + employeeId + ", employeeName="
				+ employeeName + ", employeeSal=" + employeeSal + ", sBU="
				+ sBU + "]");
		System.out.println(sBU.getSbuDetails());
	}

	
		
	}



	
	

