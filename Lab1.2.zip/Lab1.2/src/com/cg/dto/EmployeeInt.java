package com.cg.dto;

public interface EmployeeInt 
{
	public void getAllEmployeeDetail();
	
}
