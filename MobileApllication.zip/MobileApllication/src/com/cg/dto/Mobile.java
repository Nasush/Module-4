package com.cg.dto;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Mobile
{
	@Id
	private int mobileId;
	private String mobileName;
	private String mobileCategory;
	private double mobilePrice;
	private String MobileOnline;
	
	public int getMobileId() 
	{
		return mobileId;
	}
	public void setMobileId(int mobileId) 
	{
		this.mobileId = mobileId;
	}
	public String getMobileName()
	{
		return mobileName;
	}
	public void setMobileName(String mobileName)
	{
		this.mobileName = mobileName;
	}
	public String getMobileCategory()
	{
		return mobileCategory;
	}
	public void setMobileCategory(String mobileCategory) 
	{
		this.mobileCategory = mobileCategory;
	}
	public double getMobilePrice()
	{
		return mobilePrice;
	}
	public void setMobilePrice(double mobilePrice)
	{
		this.mobilePrice = mobilePrice;
	}
	public String getMobileOnline() 
	{
		return MobileOnline;
	}
	public void setMobileOnline(String mobileOnline) 
	{
		MobileOnline = mobileOnline;
	}
	
	

}
