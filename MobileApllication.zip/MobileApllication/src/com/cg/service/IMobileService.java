package com.cg.service;

import java.util.List;

import com.cg.dto.Mobile;

public interface IMobileService 
{
	public void addMobileData(Mobile mob);
	public List<Mobile>showAllMobile();
}
