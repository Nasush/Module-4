package com.cg.dao;

import java.util.List;

import com.cg.dto.Mobile;


public interface IMobileDao 
{
	public void addMobileData(Mobile mob);
	public List<Mobile>showAllMobile();
	public void deleteMobile(int mobId);
}
