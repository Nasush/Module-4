package com.cg.gear.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.gear.dto.Gear;
import com.cg.gear.exception.GearException;
import com.cg.gear.service.IGearService;



@Controller
public class GearController {

	@Autowired
	private IGearService gearService;
	
	@RequestMapping(value="show",method=RequestMethod.GET)
	public String showHomePage(@ModelAttribute("myGear") Gear gear){
		return "home";
	}
	
	@RequestMapping(value="search",method=RequestMethod.GET)
	public ModelAndView search(@ModelAttribute("myGear") Gear gear,Map<String,Object> model1){
		ModelAndView model = new ModelAndView();
		Gear bean1=new Gear();
		
		try {
			bean1=gearService.viewQueryDetails(gear.getQueryId());
			List<String> solvedBy=new ArrayList<>();
			solvedBy.add("Uma");
			solvedBy.add("Rahul");
			solvedBy.add("Kavitha");
			solvedBy.add("Hema");
			model1.put("solvedBy", solvedBy);
			model.addObject("gear",bean1);
			model.setViewName("viewSuccess");
			
		} catch (GearException e) {
			model.setViewName("error");
			model.addObject("message","Unable to view in controller"+e.getMessage());
		}
		
		return model;
	}
	
		@RequestMapping(value="update",method=RequestMethod.POST)
	public ModelAndView update(@ModelAttribute("myGear") Gear gear){

		ModelAndView model=new ModelAndView();
		try {
			gearService.updateSolution(gear);
			return new ModelAndView("updatedSuccessfully","queryId",gear.getQueryId());
						
		} catch (GearException e) {
			model.setViewName("error");
			model.addObject("message","unable to update in dao layer"+e.getMessage());
			return model;
		}
		
	}
}
