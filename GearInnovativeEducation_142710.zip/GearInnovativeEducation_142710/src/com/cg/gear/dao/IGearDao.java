package com.cg.gear.dao;

import com.cg.gear.dto.Gear;
import com.cg.gear.exception.GearException;




public interface IGearDao {
	public Gear viewQueryDetails(int queryId)throws GearException;
	
	public boolean updateSolution(Gear gear)throws GearException; 
}
