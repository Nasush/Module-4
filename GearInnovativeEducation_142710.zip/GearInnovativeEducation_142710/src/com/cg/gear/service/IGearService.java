package com.cg.gear.service;

import com.cg.gear.dto.Gear;
import com.cg.gear.exception.GearException;



public interface IGearService {
	public Gear viewQueryDetails(int queryId)throws GearException;
	
	public boolean updateSolution(Gear gear)throws GearException; 
}
