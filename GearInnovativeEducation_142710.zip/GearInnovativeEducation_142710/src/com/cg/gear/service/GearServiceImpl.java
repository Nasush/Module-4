package com.cg.gear.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.gear.dao.IGearDao;
import com.cg.gear.dto.Gear;
import com.cg.gear.exception.GearException;



@Service
public class GearServiceImpl implements IGearService {
	
	@Autowired
	private IGearDao gearDao;
	
	
	
	public IGearDao getGearDao() {
		return gearDao;
	}



	public void setGearDao(IGearDao gearDao) {
		this.gearDao = gearDao;
	}



	@Override
	public Gear viewQueryDetails(int queryId) throws GearException {
		
		return gearDao.viewQueryDetails(queryId);
	}



	@Override
	public boolean updateSolution(Gear gear) throws GearException {
		
		return gearDao.updateSolution(gear);
	}

}
