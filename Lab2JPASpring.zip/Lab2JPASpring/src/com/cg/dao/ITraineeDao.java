package com.cg.dao;

import java.util.List;

import com.cg.dto.Trainee;

public interface ITraineeDao 
{
	public void addTrainee(Trainee tr);
	public List<Trainee>showTraineeById(int trId);
	public void deleteTrainee(int tId);
	public List<Trainee>showAllTrainee();
	void updateRecord(Trainee record);
}
